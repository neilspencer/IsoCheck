# a function that applies a collineation C to a spread spr in order to relabel it.
applyCollineation <- function(C, spr){
  ddd <- dim(spr)
  out <- array(NA, ddd)
  for(i in 1:ddd[3]){
    for(j in 1:ddd[2]){
      out[,j,i] <- (C %*% spr[,j,i])%%2
    }
  }
  return(out)
}

# a function that converts a spread spr into its bitstring characterization (for checking equivalence)
getBitstrings <- function(spr){
  ddd <- dim(spr)
  n <- ddd[1]
  mult <- 2^(0:(n-1))
  strings <- matrix(0, nrow = ddd[3], ncol = 2^n -1)
  smallests <- rep(NA, ddd[3])
  for(flat in 1:(ddd[3])){
    for(pencil in 1:(ddd[2])){
      ind <- sum(mult * spr[,pencil, flat])
      strings[flat, ind] <- 1
    }
    smallests[flat] <- which.max(strings[flat,] == 1)
  }
  sort_order <- sort(smallests, index.return = T)$ix
  return(strings[sort_order,])
}

# a function for checking the isomorphism of two spreads (spread1 and spread2)
# Returns a list consisting of two components --- a boolean indicating whether
# or not spread1 is isomorphic to spread2, and a list of isomorphism establishing
# collineations. Note that when returnfirstIEC = T, only the first IEC is
# returned (much faster runtime if they are isomorphic)
checkSpreadIsomorphism <- function(spread1, spread2, returnfirstIEC = F, printstatement = T){
  if(sum(dim(spread1) == dim(spread2)) != 3){
    print("Spreads are not of same dimension.")
    return(FALSE)
  }
  n <- dim(spread1)[1]
  t <- log(dim(spread1)[2] + 1)/log(2)
  ell <- n/t
  mu <- (2^n - 1)/(2^t - 1)
  flatsize <- 2^t-1
  spacesize <- 2^n -1

  # note: for the code to work, the pencils in each flat in the spreads being checked for ismorphism
  # should be arranged such that they are isomorphic to the yates order (basis elements in slots 1,2,4,8,etc.)
  # furthermore, the union of the first ell flats should span PG(n-1,2)
  # the following 2 steps permute within the equivalence class to guarantee these criteria are met.
  spread1 <- .arrange_yates(spread1)
  spread1 <- .arrange_flats_independent(spread1)
  spread2 <- .arrange_yates(spread2)
  spread2 <- .arrange_flats_independent(spread2)


  pencilmappingoptions <- .getpenciloptions(t)


  CxB <- .getCxB(spread1)
  spreadB <- applyCollineation(CxB, spread1)
  bits2 <- getBitstrings(spread2) # get the bitstring characterization of spread2

  flatchoices <- gtools::combinations(mu, ell) # all of the ways to choose ell out of mu flats
  perms <- gtools::permutations(ell,ell) # all of the ways to permute a sequence of ell flats
  basischoices <- gtools::permutations(nrow(pencilmappingoptions),ell, repeats.allowed = T) # all of the ways to choose bases from the ell flats

  count <- 0 # the number of IECs found so far
  validCBys <- list() # a list to collect our CBys corresponding to IECs
  totaloptions <- nrow(flatchoices) * nrow(basischoices) * nrow(perms) # this should be equal to the size of the space to be searched

  # iterate across flat choices for y1...yn
  for(kk in 1:nrow(flatchoices)){
    # first check if this choice of flats form a linearly independent set, if not skip.
    xx <- .getCxB(spread2[,,flatchoices[kk,]])
    if(is.na(xx[1,1]) == F){
      # iterate through the different options for bases of the flats
      for(vv in 1:nrow(basischoices)){
        # iterate through the different permutations
        for(ww in 1:nrow(perms)){
          # create the CBy
          CBy <- matrix(nrow = n, ncol = n)
          for(i in 1:ell){
            for(j in 1:t){
              CBy[,t * (i-1) +j] <- spread2[,pencilmappingoptions[basischoices[vv, i],j], flatchoices[kk, perms[ww,i]]]
            }
          }
          relabelled <- applyCollineation(CBy, spreadB) # relabel spread1 with CBy
          bitsnew <- getBitstrings(relabelled) # get the bitstring characterization
          if(sum(bitsnew != bits2) == 0){ # check equivalence. If equivalent, add to list
            if(returnfirstIEC == T){
              return(list(result = T, IECs = list((CBy %*% CxB) %%2)))
            }
            count <- count + 1
            validCBys[[count]] <- CBy
          }
        }
        print(paste("percent done:", 100 * round(((kk-1) *nrow(basischoices) * nrow(perms) + (vv)*nrow(perms))  /totaloptions ,4))) # to help keep track of how far along we are
      }
    }
  }
  if(count == 0){
    if(printstatement == T){
      print("The two spreads are not isomorphic.")
    }
    return(list(result = FALSE, IECs = NA))
  }

  IECs <- validCBys
  for(i in 1:length(IECs)){
    IECs[[i]] <- (validCBys[[i]] %*% CxB) %%2
  }
  if(printstatement == T){
    print("The two spreads are isomorphic. For example, one isomorphism establishing collineation is")
    print(IECs[[1]])
  }

  return(list(result = T , IECs = IECs))
}

# a function that converts a star to its corresponding spread
star_to_spread <- function(star){
  ddd <- dim(star)
  n <- ddd[1]
  t <- log(ddd[2] + 1)/log(2)

  # find nucleus
  df <- suppressMessages(plyr::match_df(data.frame(t(star[,,1])), data.frame(t(star[,,2]))))

  # find dimension of nucleus
  t0 <- log(nrow(df) + 1)/log(2)

  # find basis for nucelus
  if(nrow(df) == 1){
    nucleus <- as.matrix(df)
  }else{
    nucleus <- .rrefmod2(as.matrix(df))[1:t0,]
  }

  alls <- matrix(0, nrow = 2^n, ncol = n)
  for(i in 1:n){
    alls[(floor((0:(2^n-1))/(2^(i-1))) %%2 == 1),i] <- 1
  }
  alls <- alls[-1,]
  newbasis <- nucleus
  for(i in t0:(n - 1)){
    newbasisspan <- t((t(newbasis) %*% t(alls[1:(2^i - 1), 1:i])) %% 2)
    remalls <- suppressMessages(dplyr::anti_join(data.frame(alls), data.frame(newbasisspan)))
    newbasis <- rbind(remalls[1,], newbasis)
  }


  # remove nucleus with collineation

  collineation <- solve(t(newbasis))%%2
  transformed <- applyCollineation(collineation, star)
  spread <- array(NA, c(n - t0, 2^(t - t0) - 1 , ddd[3] ))
  for(i in 1:ddd[3]){
    spread[,,i] <- transformed[1:(n-t0),which(colSums(matrix(transformed[n-t0 + (1:t0), ,i], nrow = t0)) == 0),i]
  }
  return(list(spread, collineation = collineation))
}

# receives two stars star1 and star2 as arrays(n, 2^t-1, mu) and checks their isomorphism. Returns a list containing FALSE is the two stars
# are not isomorphic. If they are isomorphic, it returns a list consisting of T as well
# as a list of IECs from star1 to star2. If returnfirstIEC = T, then only the
# If returnfirstIEC = T the algorithm terminates as soon as the first IEC is found.

checkStarIsomorphism <- function(star1, star2, returnfirstIEC = F){
  reduce1 <- star_to_spread(star1)
  reduce2 <- star_to_spread(star2)
  spread1 <- reduce1[[1]]
  spread2 <- reduce2[[1]]
  starcol1 <- reduce1$collineation
  starcol2 <- reduce2$collineation

  isocheck <- checkSpreadIsomorphism(spread1, spread2, returnfirstIEC, FALSE)
  if(isocheck[[1]] == FALSE){
    print("The two stars are not isomorphic.")
    return(list(result = FALSE, IECs = NA))
  }
  else{
    results <- list()
    transafter <- starcol1
    transbeforeinv <- starcol2
    transbefore <- solve(transbeforeinv) %% 2
    for(i in 1:length(isocheck[[1]])){
      fullmat <- diag(dim(star1)[1])
      fullmat[1:(dim(spread1)[1]), 1:(dim(spread1)[1])] <- isocheck[[2]][[i]]
      results[[i]] <- (transbefore %*% fullmat %*% transafter) %%2
    }
    print("The two stars are isomorphic. For example, one isomorphism establishing collineation is")
    print(results[[1]])
    return(list(result = T, IECs = results))
  }
}

# checks the equivalence of star1 and star2.
checkStarEquivalence <- function(star1, star2){
  strings1 <- getBitstrings(star1)
  strings2 <- getBitstrings(star2)
  mat <- matrix(log(1:ncol(strings1)), nrow = nrow(strings1), ncol = ncol(strings1), byrow = T)
  if(sum(abs(sort(rowSums(strings1 * mat)) - sort(rowSums(strings2 * mat))) < 0.00001) == nrow(strings1)){
    return(T)
  }
  else{
    return(F)
  }
}

# checks the equivalence of spread1 and spread2.
checkSpreadEquivalence <- function(spread1, spread2){
  strings1 <- getBitstrings(spread1)
  strings2 <- getBitstrings(spread2)
  if(sum(strings1 != strings2) == 0){
    return(T)
  }
  return(F)
}
